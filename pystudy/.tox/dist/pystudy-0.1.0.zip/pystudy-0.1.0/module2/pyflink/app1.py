#!/usr/bin/python


def app1(x):
    return x + 1